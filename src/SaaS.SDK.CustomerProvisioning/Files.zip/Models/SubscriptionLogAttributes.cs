﻿namespace Microsoft.Marketplace.SaasKit.Client.Models
{
    public enum SubscriptionLogAttributes
    {
        Plan = 1,
        Status = 2,
        Quantity = 3
    }
}
