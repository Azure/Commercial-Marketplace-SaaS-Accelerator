﻿namespace Microsoft.Marketplace.Saas.Web.Models
{
    public enum EventLogAttributes
    {
        Activate = 1,
        UnSubscribe = 2
    }
}
