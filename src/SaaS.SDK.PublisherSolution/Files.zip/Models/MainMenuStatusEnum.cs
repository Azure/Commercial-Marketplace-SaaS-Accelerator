﻿namespace Microsoft.Marketplace.Saas.Web.Models
{
    /// <summary>
    /// Sets Subscription Operation Status
    /// </summary>
    public enum MainMenuStatusEnum
    {
        /// <summary>
        /// Is Active Enable
        /// </summary>
        IsLicenseManagementEnabled,

       

    }
}