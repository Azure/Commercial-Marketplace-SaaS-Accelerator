﻿namespace Microsoft.Marketplace.Saas.Web.Models
{
    public enum SubscriptionLogAttributes
    {
        Plan = 1,
        Status = 2,
        ProviderCount = 3,
        Metered = 4
    }
}
